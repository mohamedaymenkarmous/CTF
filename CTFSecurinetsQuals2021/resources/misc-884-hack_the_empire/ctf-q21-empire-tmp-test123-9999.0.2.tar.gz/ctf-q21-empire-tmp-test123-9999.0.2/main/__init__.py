def main():
    print("Bye world")
